from django.apps import AppConfig


class Dummy2Config(AppConfig):
    name = 'dummy2'
