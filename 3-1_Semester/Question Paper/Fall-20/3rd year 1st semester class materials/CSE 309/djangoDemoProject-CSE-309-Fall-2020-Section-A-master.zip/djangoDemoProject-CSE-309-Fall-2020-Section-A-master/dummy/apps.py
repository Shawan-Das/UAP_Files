from django.apps import AppConfig


class DummyConfig(AppConfig):
    name = 'dummy'
