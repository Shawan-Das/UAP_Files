from django.contrib import admin
from Student.models import Student,StudentInfo
from .models import Semester, Course

# Register your models here.
admin.site.register(Semester)
